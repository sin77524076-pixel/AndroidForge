# MYTH Plus — Android Personal AI Assistant

This upgraded learning project adds:
- AI chat with MYTH's funny, friendly personality
- Android speech-to-text input and text-to-speech replies
- Local personal notes/memory saved on the phone
- Local notification reminders
- A shortcut to create a calendar event in the phone's calendar app
- Optional automatic web search through the OpenAI Responses API

## Requirements

- A computer running Windows, macOS or Linux
- Android Studio
- Node.js 18+
- An OpenAI API key with API billing/credits enabled
- An Android phone or emulator

A ChatGPT subscription does not include API usage; API billing is separate.

## 1. Configure the backend

Install Node.js from https://nodejs.org/.

Open a terminal in the `backend` folder and run:

```bash
npm install
```

Copy `.env.example` to `.env`, then edit `.env`:

```env
OPENAI_API_KEY=your_real_api_key
OPENAI_MODEL=gpt-6-astra
PORT=3000
```

Keep `.env` secret. Do not place your API key in Android source code or commit it to Git.

If the model is not enabled for your API account, set `OPENAI_MODEL` to a model your account can use.

Start the server:

```bash
npm start
```

Check `http://localhost:3000/health` on the computer. It should return JSON with `"ok": true`.

## 2. Open the Android app

1. Install Android Studio: https://developer.android.com/studio
2. Extract this project ZIP.
3. In Android Studio, choose **Open** and select the extracted `MYTH-Android-Assistant-Plus` folder.
4. Wait for Gradle sync.
5. Start an emulator or connect your Android phone with USB debugging.
6. Press **Run**.

## 3. Connect a real phone to the backend

The default URL `http://10.0.2.2:3000/` is for the Android emulator only.

For a physical phone:
1. Connect phone and computer to the same Wi-Fi.
2. Find the computer's local IPv4 address.
3. Edit `app/build.gradle.kts` and replace the API URL, for example:

```kotlin
buildConfigField("String", "API_BASE_URL", "\"http://192.168.1.20:3000/\"")
```

Use your actual computer IP, not the sample address.
4. Allow Node.js through the computer firewall on your private network.
5. Sync and run again.

## 4. Features

### Chat and voice
- Type and send messages.
- Tap the microphone to dictate a message, then tap Send.
- Enable the Voice switch to hear assistant replies.
- Tap Read aloud to repeat a response.

Voice input uses Android's speech-recognition service. It is push-to-talk, not an always-listening wake word. Spoken replies use Android TextToSpeech.

### Personal memory
Open the Memory tab and write notes you want MYTH to use in future conversations. Tap Save memory. Notes are stored locally in app preferences and sent to your backend with each chat request. They are not encrypted in this starter project; do not store secrets, passwords, financial credentials or highly sensitive information.

### Planner and reminders
Open Planner, enter a reminder and a number of minutes, then tap Set reminder. Android will schedule a local notification. Allow notifications when asked. You can delete a reminder from the list. The minutes field is relative to the time you create the reminder; it is not a full date/time scheduler.

The Calendar button opens the phone's calendar app with a new event draft. You must review and save it yourself.

### Internet intelligence
The backend enables the Responses API `web_search` tool. MYTH can decide when web search is useful. Web search API usage may incur additional charges.

## 5. Important limitations

This is a functional starter project, not a published production app:
- Voice is push-to-talk speech recognition plus Android text-to-speech, not continuous natural speech-to-speech or a wake-word listener.
- Memory is a user-editable local notes field, not automatic long-term learning.
- Reminders are local one-off notifications scheduled in minutes, not recurring reminders or cloud sync.
- Calendar integration opens the phone's calendar app; it does not silently read or edit your calendar.
- Chat history is held in app memory while the app remains open; it is not yet persisted.
- Web search is performed by the backend model tool; source citations appear as text if returned by the API.

## 6. Security before public release

This starter uses HTTP for local development, has no authentication or rate limiting, and is not safe to expose publicly as-is.

Before public release:
- Deploy the backend with HTTPS.
- Add authentication and per-user rate limits.
- Keep API keys in server-side secret storage.
- Add abuse prevention, logging and privacy controls.
- Use secure storage/encryption for personal memory.
- Review Play Store policies and applicable privacy laws.
- Remove cleartext traffic permission and use your HTTPS endpoint.

## Project structure

```text
MYTH-Android-Assistant-Plus/
├── app/
│   ├── build.gradle.kts
│   └── src/main/
│       ├── AndroidManifest.xml
│       └── java/com/myth/assistant/
│           ├── MainActivity.kt
│           └── ReminderReceiver.kt
├── backend/
│   ├── server.js
│   ├── package.json
│   ├── .env.example
│   └── .gitignore
├── build.gradle.kts
├── settings.gradle.kts
└── README.md
```
