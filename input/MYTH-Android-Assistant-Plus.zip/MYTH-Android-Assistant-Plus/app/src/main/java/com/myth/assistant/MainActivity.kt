package com.myth.assistant

import android.Manifest
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.CalendarContract
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddAlarm
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

private data class ChatLine(val role: String, val text: String)
private data class Reminder(val id: Int, val title: String, val minutes: Int)

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private val prefs by lazy { getSharedPreferences("myth_local_data", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        requestNotificationPermissionIfNeeded()
        setContent { MythApp() }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 501)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts?.language = Locale.getDefault()
    }

    private fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "myth_reply")
    }

    private fun scheduleReminder(id: Int, title: String, minutes: Int) {
        val intent = Intent(this, ReminderReceiver::class.java).putExtra("title", title)
        val pending = PendingIntent.getBroadcast(
            this, id, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val alarm = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val at = System.currentTimeMillis() + minutes.coerceAtLeast(1) * 60_000L
        alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pending)
    }

    private fun saveReminders(list: List<Reminder>) {
        val array = JSONArray()
        list.forEach { array.put(JSONObject().put("id", it.id).put("title", it.title).put("minutes", it.minutes)) }
        prefs.edit().putString("reminders", array.toString()).apply()
    }

    private fun loadReminders(): List<Reminder> = runCatching {
        val arr = JSONArray(prefs.getString("reminders", "[]"))
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Reminder(o.getInt("id"), o.getString("title"), o.getInt("minutes"))
        }
    }.getOrDefault(emptyList())

    @Composable
    private fun MythApp() {
        var tab by remember { mutableStateOf("Chat") }
        val messages = remember {
            mutableStateListOf(
                ChatLine("assistant", "Hey! I'm MYTH — your witty AI sidekick. I can chat, remember notes, set reminders and search the web. Let's make today less chaotic.")
            )
        }
        var draft by remember { mutableStateOf("") }
        var busy by remember { mutableStateOf(false) }
        var speakReplies by remember { mutableStateOf(true) }
        var error by remember { mutableStateOf<String?>(null) }
        var memory by remember { mutableStateOf(prefs.getString("memory", "") ?: "") }
        var memoryDraft by remember { mutableStateOf(memory) }
        val reminders = remember { mutableStateListOf<Reminder>().apply { addAll(loadReminders()) } }
        var reminderTitle by remember { mutableStateOf("") }
        var reminderMinutes by remember { mutableStateOf("10") }

        val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spoken.isNullOrBlank()) draft = spoken
        }

        fun listen() {
            try {
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                    putExtra(RecognizerIntent.EXTRA_PROMPT, "Talk to MYTH")
                }
                speechLauncher.launch(intent)
            } catch (_: Exception) { error = "Speech recognition isn't available. Text chat still works." }
        }

        fun sendMessage() {
            val prompt = draft.trim()
            if (prompt.isEmpty() || busy) return
            messages.add(ChatLine("user", prompt))
            draft = ""
            busy = true
            error = null
            lifecycleScope.launch {
                try {
                    val reply = withContext(Dispatchers.IO) { callMythApi(messages.toList().takeLast(16), memory) }
                    messages.add(ChatLine("assistant", reply))
                    if (speakReplies) speak(reply)
                } catch (e: Exception) {
                    error = e.message ?: "Couldn't reach MYTH. Check the backend and network."
                } finally { busy = false }
            }
        }

        MaterialTheme(colorScheme = darkColorScheme(
            primary = Color(0xFF9B8CFF), secondary = Color(0xFF65D6D0),
            background = Color(0xFF0D1020), surface = Color(0xFF171B30)
        )) {
            Surface(Modifier.fillMaxSize(), color = Color(0xFF0D1020)) {
                Column(Modifier.fillMaxSize().padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("MYTH", fontSize = 30.sp, fontWeight = FontWeight.Black, color = Color(0xFFB8AEFF))
                            Text("YOUR PERSONAL AI SIDEKICK", fontSize = 10.sp, letterSpacing = 2.sp, color = Color.LightGray)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Voice", color = Color.LightGray, fontSize = 12.sp)
                            Switch(checked = speakReplies, onCheckedChange = { speakReplies = it })
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    TabRow(selectedTabIndex = listOf("Chat", "Memory", "Planner").indexOf(tab)) {
                        listOf("Chat", "Memory", "Planner").forEachIndexed { index, label ->
                            Tab(selected = tab == label, onClick = { tab = label }, text = { Text(label) })
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    when (tab) {
                        "Chat" -> {
                            LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                items(messages) { line ->
                                    val user = line.role == "user"
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (user) Arrangement.End else Arrangement.Start) {
                                        Column(Modifier.widthIn(max = 310.dp).background(
                                            if (user) Color(0xFF34305C) else Color(0xFF1B2238),
                                            RoundedCornerShape(18.dp)
                                        ).padding(13.dp)) {
                                            Text(if (user) "YOU" else "MYTH", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF9DDBD6))
                                            Spacer(Modifier.height(4.dp))
                                            Text(line.text, color = Color.White, fontSize = 15.sp)
                                            if (!user) TextButton(onClick = { speak(line.text) }) {
                                                Icon(Icons.Default.VolumeUp, contentDescription = null)
                                                Text("Read aloud")
                                            }
                                        }
                                    }
                                }
                                if (busy) item { Text("MYTH is thinking…", color = Color.LightGray) }
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                OutlinedTextField(draft, { draft = it }, Modifier.weight(1f),
                                    placeholder = { Text("Message MYTH…") }, maxLines = 4, enabled = !busy,
                                    shape = RoundedCornerShape(22.dp))
                                IconButton(onClick = { listen() }, enabled = !busy) {
                                    Icon(Icons.Default.Mic, contentDescription = "Speak", tint = Color(0xFF65D6D0))
                                }
                                IconButton(onClick = { sendMessage() }, enabled = !busy && draft.isNotBlank()) {
                                    Icon(Icons.Default.Send, contentDescription = "Send", tint = Color(0xFFB8AEFF))
                                }
                            }
                        }
                        "Memory" -> {
                            Text("MYTH'S PRIVATE NOTES", color = Color(0xFF9DDBD6), fontWeight = FontWeight.Bold)
                            Text("Add facts you want MYTH to use in future chats, such as preferences, goals or project details. Stored on this phone.", color = Color.LightGray, fontSize = 13.sp)
                            OutlinedTextField(
                                value = memoryDraft, onValueChange = { memoryDraft = it },
                                modifier = Modifier.fillMaxWidth().weight(1f),
                                placeholder = { Text("Example: I prefer simple explanations. My current project is…") },
                                minLines = 8, maxLines = 16
                            )
                            Button(onClick = {
                                memory = memoryDraft.take(8000)
                                prefs.edit().putString("memory", memory).apply()
                                error = "MYTH memory saved on this device."
                            }, modifier = Modifier.fillMaxWidth()) {
                                Icon(Icons.Default.Save, contentDescription = null)
                                Text(" Save memory")
                            }
                            Text("Avoid storing passwords, payment details or other secrets.", color = Color.Gray, fontSize = 11.sp)
                        }
                        else -> {
                            Text("REMINDERS", color = Color(0xFF9DDBD6), fontWeight = FontWeight.Bold)
                            Text("Create a notification for a number of minutes from now.", color = Color.LightGray, fontSize = 13.sp)
                            OutlinedTextField(reminderTitle, { reminderTitle = it }, Modifier.fillMaxWidth(),
                                label = { Text("What should MYTH remind you?") }, singleLine = true)
                            OutlinedTextField(reminderMinutes, { reminderMinutes = it.filter(Char::isDigit).take(5) },
                                Modifier.fillMaxWidth(), label = { Text("Remind me in how many minutes?") }, singleLine = true)
                            Button(onClick = {
                                val mins = reminderMinutes.toIntOrNull()
                                if (reminderTitle.isBlank() || mins == null || mins < 1) {
                                    error = "Enter a reminder and a number of minutes (at least 1)."
                                } else {
                                    val id = (System.currentTimeMillis() % Int.MAX_VALUE).toInt()
                                    val item = Reminder(id, reminderTitle.trim(), mins)
                                    reminders.add(item)
                                    saveReminders(reminders)
                                    scheduleReminder(id, item.title, mins)
                                    reminderTitle = ""
                                    error = "Reminder scheduled. MYTH will notify you."
                                }
                            }, modifier = Modifier.fillMaxWidth()) {
                                Icon(Icons.Default.AddAlarm, contentDescription = null)
                                Text(" Set reminder")
                            }
                            Spacer(Modifier.height(8.dp))
                            Text("UPCOMING", color = Color(0xFF9DDBD6), fontWeight = FontWeight.Bold)
                            LazyColumn(Modifier.weight(1f)) {
                                items(reminders) { item ->
                                    ListItem(
                                        headlineContent = { Text(item.title) },
                                        supportingContent = { Text("In ${item.minutes} minute(s) from when it was created") },
                                        trailingContent = {
                                            IconButton(onClick = {
                                                val pending = PendingIntent.getBroadcast(
                                                    this@MainActivity, item.id, Intent(this@MainActivity, ReminderReceiver::class.java),
                                                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                                                )
                                                (getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pending)
                                                reminders.remove(item); saveReminders(reminders)
                                            }) { Icon(Icons.Default.Delete, contentDescription = "Delete reminder") }
                                        }
                                    )
                                    Divider()
                                }
                            }
                            OutlinedButton(onClick = {
                                val intent = Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI)
                                intent.putExtra(CalendarContract.Events.TITLE, "Plan with MYTH")
                                intent.putExtra(CalendarContract.Events.DESCRIPTION, "Created from MYTH assistant")
                                runCatching { startActivity(intent) }.onFailure { error = "No calendar app is available." }
                            }, modifier = Modifier.fillMaxWidth()) {
                                Icon(Icons.Default.CalendarMonth, contentDescription = null)
                                Text(" Open calendar")
                            }
                        }
                    }
                    error?.let { Text(it, color = Color(0xFFFFA0A0), fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)) }
                    Text("Speech recognition and notifications depend on Android permissions and device settings.",
                        color = Color.Gray, fontSize = 10.sp, modifier = Modifier.padding(top = 6.dp))
                }
            }
        }
    }

    private fun callMythApi(history: List<ChatLine>, memory: String): String {
        val connection = (URL(BuildConfig.API_BASE_URL + "chat").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; connectTimeout = 20000; readTimeout = 90000
            doOutput = true; setRequestProperty("Content-Type", "application/json")
        }
        try {
            val body = JSONObject()
                .put("memory", memory)
                .put("messages", JSONArray().apply {
                    history.forEach { put(JSONObject().put("role", it.role).put("content", it.text)) }
                })
            connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val stream = if (connection.responseCode in 200..299) connection.inputStream else connection.errorStream
            val response = stream.bufferedReader().use { it.readText() }
            if (connection.responseCode !in 200..299) {
                val msg = runCatching { JSONObject(response).optString("error") }.getOrNull()
                throw IllegalStateException(msg?.takeIf { it.isNotBlank() } ?: "Server error ${connection.responseCode}")
            }
            return JSONObject(response).optString("reply").ifBlank { "I got an empty reply. Try again?" }
        } finally { connection.disconnect() }
    }

    override fun onDestroy() {
        tts?.stop(); tts?.shutdown()
        super.onDestroy()
    }
}
